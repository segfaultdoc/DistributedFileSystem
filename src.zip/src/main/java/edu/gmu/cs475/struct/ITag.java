package edu.gmu.cs475.struct;

public interface ITag {

	public String getName();
}
