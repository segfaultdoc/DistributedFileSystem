package edu.gmu.cs475.struct;

public interface ITaggedFile {
	public String getName();
}
