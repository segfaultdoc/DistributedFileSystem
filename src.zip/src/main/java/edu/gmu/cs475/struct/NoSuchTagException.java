package edu.gmu.cs475.struct;

import java.io.IOException;

public class NoSuchTagException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1517821833623681001L;
	
}
