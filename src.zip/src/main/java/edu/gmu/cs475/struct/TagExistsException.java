package edu.gmu.cs475.struct;

import java.io.IOException;

public class TagExistsException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 456522817237846381L;

}
